# This project has moved to [https://github.com/christabor/widgetpack](https://github.com/christabor/widgetpack)

[![MIT Badge](http://img.shields.io/badge/license-MIT-blue.svg)](https://raw.githubusercontent.com/christabor/css-drawer-menu/master/LICENSE)

css-drawer-menu
===============

An ultra light mobile side "drawer" menu in pure css. 2kb!
